# apps/catalog/templatetags/__init__.py

# Пустой файл для регистрации тегов и фильтров
