# apps/users/__init__.py

import apps.users.templatetags.custom_filters
