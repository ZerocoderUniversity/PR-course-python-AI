// static/js/scripts.js

