# telegramadmin_bot/config.py

from django.conf import settings

ADMIN_BOT_TOKEN = settings.ADMIN_BOT_TOKEN
ADMIN_TELEGRAM_IDS = settings.ADMIN_TELEGRAM_IDS
ADMIN_API_TOKEN = settings.ADMIN_API_TOKEN

