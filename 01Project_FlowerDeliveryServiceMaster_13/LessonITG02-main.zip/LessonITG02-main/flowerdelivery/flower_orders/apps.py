from django.apps import AppConfig

class FlowerOrdersConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'flower_orders'

