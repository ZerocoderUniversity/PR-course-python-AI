from django.apps import AppConfig


class TelegramBotConfig(AppConfig):
    name = "apps.telegram_bot"
