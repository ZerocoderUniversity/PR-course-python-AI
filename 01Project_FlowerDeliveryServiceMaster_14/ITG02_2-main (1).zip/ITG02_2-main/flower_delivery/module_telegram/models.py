"""
Путь: module_telegram/models.py
Модели для работы с Telegram-ботом.
"""

# Удалён неиспользуемый импорт models
