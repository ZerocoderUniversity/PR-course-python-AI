# module_orders/__init__.py
default_app_config = 'module_orders.apps.ModuleOrdersConfig'
